
import Todo from "./Todo";
const App=()=> {
  return(
  <>
 <Todo/>
  </>
  );
}

export default App;
