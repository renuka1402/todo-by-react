let express=require("express");
let app=express();
let mongoose=require("mongoose");
const cors=require("cors");
app.use(cors());
const bodyParser=require("body-parser");

mongoose.connect("mongodb://127.0.0.1:27017/janvi");
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json());
const stuController=require("./controllers/employeeController");

app.post("/insertData",stuController.InsertData);
app.get("/displayData",stuController.DisplayData)
app.listen(8000);