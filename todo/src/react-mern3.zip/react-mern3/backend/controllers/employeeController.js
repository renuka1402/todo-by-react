
const stuModel=require("../models/employeeModel");

const InsertData=async(req,res)=>{
    let empNo=req.body.empno;
    let empNm=req.body.empnm;
    let empCt =req.body.empct;
    let empSell=req.body.empsell;
    const mydata=new stuModel({
        empnumber:empNo,
        empname:empNm,
        empcity:empCt,
         empsallary:empSell
    })
    mydata.save();
   // let myData=({rollno:roll,name:name,city:city,fees:fees})
   // console.log(myData);
    res.json(mydata);
}
const DisplayData=async(req,res)=>{
    stuModel.find().then((mydata)=>{
        res.json(mydata);
    })
}
module.exports={
    InsertData,
    DisplayData
}