

const Home=()=>{
    return(
        <>
        <h1>Welcome to Home page</h1>
        </>
    );
}
export default Home;