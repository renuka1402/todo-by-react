import axios from "axios";
import { useState } from "react";

const Insert=()=>{
    const [myinput,setMyinput]=useState({});

    const handleInput=(e)=>{
       let name=e.target.name;
       let value=e.target.value;
       setMyinput(values=>({...values,[name]:value}));

    }
    const handleSubmit=()=>{
       let api="http://localhost:8000/insertData";
       axios.post(api,myinput).then((res)=>{
       // console.log(res.data);
       alert("data insert!!")
       })
    }
    return(
        <>
        Enter employee number:<input type="text" name="empno" onChange={handleInput}/>
        <br/>
        Enter employee name:<input type="text" name="empnm" onChange={handleInput}/>
        <br/>
        Enter employee city:<input type="text" name="empct" onChange={handleInput}/>
        <br/>
        Enter employee sallary:<input type="text" name="empsell" onChange={handleInput}/>
        <br/>
        <button  onClick={handleSubmit}>Save Data!!</button>
        </>
    );
}
export default Insert;